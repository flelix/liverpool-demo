package com.test.demo.response;

import lombok.Data;

@Data
public class ResponseOk {
    private String message;
    private Object result;
}
