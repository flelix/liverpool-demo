package com.test.demo.controller;

import com.test.demo.model.EmployeeModel;
import com.test.demo.response.ResponseOk;
import com.test.demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/{id}")
    public ResponseEntity<ResponseOk> getEmployeebyId(@PathVariable(name = "id") int id){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Employee was found ");
        responseOk.setResult(employeeService.getEmployeebyId(id));
        return ResponseEntity.ok().body(responseOk);
    }

    @PostMapping("/insert")
    public ResponseEntity<ResponseOk> createEmployee(@RequestBody EmployeeModel employee){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Employee was inserted suscessfully ");
        responseOk.setResult(employeeService.createEmployee(employee));
        return ResponseEntity.ok().body(responseOk);
    }

    @GetMapping("/")
    public ResponseEntity<ResponseOk> findAllEmployess(){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Employees was found ");
        responseOk.setResult(employeeService.findAllEmployess());
        return ResponseEntity.ok().body(responseOk);
    }

}
