package com.test.demo.service;

import com.test.demo.model.DepartmentModel;
import com.test.demo.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;


    public DepartmentModel getDepartmentId(Integer id) {
        return departmentRepository.findById(id).orElse(new DepartmentModel());
    }

    public DepartmentModel createDepartment(DepartmentModel departmentModel) {
        return departmentRepository.save(departmentModel);
    }

    public List<DepartmentModel> createDepartment(List<DepartmentModel> departmentModel) {

        return departmentRepository.saveAll(
                departmentModel.stream()
                .distinct()
                .collect(Collectors.toList())
        );
    }

    public List<DepartmentModel> findAllDepartments(){
        return departmentRepository.findAll();
    }
}
