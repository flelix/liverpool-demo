package com.test.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "Employee")
public class EmployeeModel {

    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.SEQUENCE)
    private Integer employeeId;
    private String name;
    private String lastName;
    private int age;
    private Integer departmentId;
}
