package com.test.demo.controller;

import com.test.demo.model.DepartmentModel;
import com.test.demo.model.EmployeeModel;
import com.test.demo.response.ResponseOk;
import com.test.demo.service.DepartmentService;
import com.test.demo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/department")
public class DepartmentController {

    @Autowired
    private DepartmentService employeeService;

    @GetMapping("/{id}")
    public ResponseEntity<ResponseOk> getEmployeebyId(@PathVariable(name = "id") int id){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Department was found ");
        responseOk.setResult(employeeService.getDepartmentId(id));
        return ResponseEntity.ok().body(responseOk);
    }

    @PostMapping("/insert")
    public ResponseEntity<ResponseOk> createEmployee(@RequestBody DepartmentModel department){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Department was inserted suscessfully ");
        responseOk.setResult(employeeService.createDepartment(department));
        return ResponseEntity.ok().body(responseOk);
    }

    @PostMapping("/insertAll")
    public ResponseEntity<ResponseOk> createEmployee(@RequestBody List<DepartmentModel> departments){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Department was inserted suscessfully ");
        responseOk.setResult(employeeService.createDepartment(departments));
        return ResponseEntity.ok().body(responseOk);
    }

    @GetMapping("/")
    public ResponseEntity<ResponseOk> findAllEmployess(){
        ResponseOk responseOk = new ResponseOk();
        responseOk.setMessage("Department was found ");
        responseOk.setResult(employeeService.findAllDepartments());
        return ResponseEntity.ok().body(responseOk);
    }
}
