create table employee (
    id int auto_increment PRIMARY KEY,
    name TEXT NOT NULL,
    lastName TEXT NOT NULL,
    age int,
    idDepartment int
);

create table department (
    id int auto_increment PRIMARY KEY,
    department_name TEXT NOT NULL
);